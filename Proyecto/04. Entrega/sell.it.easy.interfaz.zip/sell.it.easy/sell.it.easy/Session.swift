//
//  Session.swift
//  sell.it.easy
//
//  Created by David Márquez Delgado on 14/8/17.
//  Copyright © 2017 David Márquez Delgado. All rights reserved.
//

import Foundation

class Session {

    var usuario : Usuario!
    var tiendaSeleccionada : Tienda?
    
    //Singleton
    static let shared = Session()
    
    
}
