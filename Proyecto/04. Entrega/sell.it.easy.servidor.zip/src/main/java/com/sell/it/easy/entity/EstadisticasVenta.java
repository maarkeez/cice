package com.sell.it.easy.entity;

import java.util.ArrayList;
import java.util.List;

public class EstadisticasVenta {

	public List<Integer> horas = new ArrayList<Integer>();
	public List<Double> dineroHoras = new ArrayList<Double>();
	public List<String> nombreVendedores = new ArrayList<String>();
	public List<Double> porcentajeVendedores = new ArrayList<Double>();
	
	public EstadisticasVenta(){

		
		
	}
	
}
