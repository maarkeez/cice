//
//  iOSCircle.m
//  Drawing Circles with UITouch
//
//  Created by Arthur Knopper on 79//12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import "iOSCircle.h"

@implementation iOSCircle

@synthesize circleCenter,circleRadius;

@end
