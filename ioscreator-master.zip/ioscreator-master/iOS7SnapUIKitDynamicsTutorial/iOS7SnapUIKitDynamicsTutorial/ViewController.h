//
//  ViewController.h
//  iOS7SnapUIKitDynamicsTutorial
//
//  Created by Arthur Knopper on 3/3/14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
