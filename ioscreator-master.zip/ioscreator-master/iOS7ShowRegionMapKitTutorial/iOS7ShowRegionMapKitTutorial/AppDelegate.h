//
//  AppDelegate.h
//  iOS7ShowRegionMapKitTutorial
//
//  Created by Arthur Knopper on 19-02-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
