//
//  iOSView.h
//  Drawing Gradients
//
//  Created by Arthur Knopper on 189//12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iOSView : UIView

@end
