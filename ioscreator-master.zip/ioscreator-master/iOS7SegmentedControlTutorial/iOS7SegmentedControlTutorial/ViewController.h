//
//  ViewController.h
//  iOS7SegmentedControlTutorial
//
//  Created by Arthur Knopper on 25-02-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
