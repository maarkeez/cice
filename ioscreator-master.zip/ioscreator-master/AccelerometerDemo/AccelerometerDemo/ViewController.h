//
//  ViewController.h
//  AccelerometerDemo
//
//  Created by Arthur Knopper on 1/29/13.
//  Copyright (c) 2013 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController

@end
