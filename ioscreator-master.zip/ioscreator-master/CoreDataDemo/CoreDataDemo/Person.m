//
//  Person.m
//  CoreDataDemo
//
//  Created by Arthur Knopper on 19/11/12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import "Person.h"


@implementation Person

@dynamic age;
@dynamic firstName;
@dynamic lastName;

@end
