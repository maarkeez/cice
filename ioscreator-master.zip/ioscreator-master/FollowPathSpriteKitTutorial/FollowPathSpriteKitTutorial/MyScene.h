//
//  MyScene.h
//  FollowPathSpriteKitTutorial
//

//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MyScene : SKScene

@end
