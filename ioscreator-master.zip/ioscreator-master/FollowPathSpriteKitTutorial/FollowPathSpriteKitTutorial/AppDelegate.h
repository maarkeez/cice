//
//  AppDelegate.h
//  FollowPathSpriteKitTutorial
//
//  Created by Arthur Knopper on 05-03-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
