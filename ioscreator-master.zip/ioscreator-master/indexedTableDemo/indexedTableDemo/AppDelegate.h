//
//  AppDelegate.h
//  indexedTableDemo
//
//  Created by Arthur Knopper on 12/13/12.
//  Copyright (c) 2012 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
