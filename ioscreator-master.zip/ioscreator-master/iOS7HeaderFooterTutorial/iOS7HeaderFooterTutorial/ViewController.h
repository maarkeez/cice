//
//  ViewController.h
//  iOS7HeaderFooterTutorial
//
//  Created by Arthur Knopper on 02-03-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
