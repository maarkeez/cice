//
//  MyCell.h
//  iOS7CustomCollectionViewCellTutorial
//
//  Created by Arthur Knopper on 10-03-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *myImageView;

@end
