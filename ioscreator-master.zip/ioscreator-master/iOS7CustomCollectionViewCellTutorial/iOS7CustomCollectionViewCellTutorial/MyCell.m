//
//  MyCell.m
//  iOS7CustomCollectionViewCellTutorial
//
//  Created by Arthur Knopper on 10-03-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
