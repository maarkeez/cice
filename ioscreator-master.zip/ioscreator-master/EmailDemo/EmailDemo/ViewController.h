//
//  ViewController.h
//  EmailDemo
//
//  Created by Arthur Knopper on 7/10/12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface ViewController : UIViewController 

@end
