//
//  IOSSecondViewController.h
//  iOS7NAvigationControllerTutorial
//
//  Created by Arthur Knopper on 16-06-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IOSSecondViewController : UIViewController

@end
