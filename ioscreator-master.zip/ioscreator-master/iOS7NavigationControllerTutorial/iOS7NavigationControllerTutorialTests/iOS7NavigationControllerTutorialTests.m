//
//  iOS7NavigationControllerTutorialTests.m
//  iOS7NavigationControllerTutorialTests
//
//  Created by Arthur Knopper on 10-06-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface iOS7NavigationControllerTutorialTests : XCTestCase

@end

@implementation iOS7NavigationControllerTutorialTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
