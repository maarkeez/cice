//
//  AppDelegate.h
//  iOS7ImageViewTutorial
//
//  Created by Arthur Knopper on 08-02-14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
